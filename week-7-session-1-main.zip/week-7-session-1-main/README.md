# week-7-session-1

* create classes and access fields in task1
* create classes with methods in task2
* import modules in another file in task3
* create classes with more methods in advanced
