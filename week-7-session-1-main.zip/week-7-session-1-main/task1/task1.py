# Define a class called Router. Each router has a model name, a software version, and an IP
# address for management. When an instance of this class is created, the value to these fields
# are passed into the __init__ method. 





# Once completed, we can create an instance of Router.
router1 = Router("iosV", "15.6.7", "10.10.10.1")

# write code to print the details of the router

