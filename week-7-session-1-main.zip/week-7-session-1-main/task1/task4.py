# Define a class Book with the following fields:
# (1) title - the book title
# (2) author - the author(s) of the book
# (3) ISBN - the International Standard Book Number, which is 10-13 digits long
# (4) availability - whether the book is available (True or False)
# When an instance of a Book is created, only the value to the first three fields are required
# for the __init__ method as the book is available when created.








# Once completed, create two instances of Book with the details of two of your favourite books.
# Write code to print the details of each books
